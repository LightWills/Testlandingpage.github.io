<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class WPBakeryShortCode_VC_Column_text extends WPBakeryShortCode {
	protected function outputTitle( $title ) {
		return '';
	}
}
